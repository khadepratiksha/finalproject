import React from 'react';
import * as s from './App.styles';
import * as Palette from './colors'

// Components
import Sidebar from './components/Sidebar/Sidebar';
import MainView from './components/MainView/MainView'


const App = () => {
  const backgroundImage = 'images/mountain.jpg';
  const sidebarHeader = {
    fullName: 'Chat Bot',
    shortName: 'CB'
  };
  const menuItems = [
    {name: 'Home', to: '/', icon: '/icons/home.svg', subMenuItems: [] },
    {name: 'About', to: '/about', icon: '/icons/about.svg', subMenuItems: [] },
    {name: 'Module Name', to: '/Module', icon: '/icons/destinations.svg', 
      subMenuItems: [
        { name: 'JAVA', to: '/canada'},        
        { name: 'Database', to: '/brazil'},
        { name: 'Operating System', to: '/india'},
        { name: 'Data Structure', to: '/australia'},
        { name: 'Web Programming', to: '/kenya'},
        { name: 'Web java', to: '/moldova'}
      ] },
    {name: 'WishList', to: '/WishList', icon: '/icons/blog.svg', subMenuItems: [] },
    {name: 'FAQ', to: '/FAQ', icon: '/icons/services.svg', subMenuItems: [] },
    {name: 'History', to: '/History', icon: '/icons/contacts.svg', subMenuItems: [] }
  ];

  const fonts = {
    header: 'ZCOOL KuaiLe',
    menu: 'Poppins'
  }

  return (
    <s.App>
      <Sidebar
        backgroundImage={backgroundImage}
        sidebarHeader={sidebarHeader}
        menuItems={menuItems}
        fonts={fonts}
        colorPalette={Palette.julyBlue}
      />
      <MainView />
    </s.App>
  );
}

export default App;
