import React from 'react';
import { Switch, Route } from 'react-router-dom';

// Components
import Home from './components/MainView/Home/Home';
import About from './components/MainView/About/About';
import Module from './components/MainView/Module/Module';
import Country from './components/MainView/Module/Country/Country'
import WishList from './components/MainView/WishList/WishList';

import History from './components/MainView/History/History';
import Chatbot from './Chatbot';
import Login from './userlogin/Login';
import UserHistory from './UserHistory';
import AdminQuestion from './AdminQuestion';
import Trydisplay from './Trydisplay';
import Model from './Model';
import FAQ from './FAQ';


const Routes = () => {
  return (
    <Switch>
      <Route exact path='/' component={Chatbot} />
      <Route exact path='/about' component={About} />
      <Route exact path='/Module' component={AdminQuestion} />
      <Route exact path='/Module/:country' component={Country} />
      <Route exact path='/WishList' component={Model} />
      <Route exact path='/FAQ' component={FAQ} />
      <Route exact path='/History' component={UserHistory} />
  
      <Route exact path="/login" component={Login}></Route>
     
    </Switch>
  )
}

export default Routes;