import React, { useState, useEffect, useLocation } from 'react'
import { Input } from "antd"
import { useCombobox } from "downshift"
import axios from 'axios';
import UserHistory from './UserHistory';
import './Tryc.css';
import Text from 'antd/lib/typography/Text';
import Grid from 'antd/lib/card/Grid';
import Images from './images/msg2.jpg'


import { Paper } from '@material-ui/core';

const Chatbot = () => {
  const paperStyle={
    height:'80vh', width:'100vh'}
  // const location = useLocation();
  const [fquestion, setFQustion] = useState([]);
  const [newtask, setTask] = useState("");
  const [questiond, setQustion] = useState([]);
  const [moduleid, setModuleid] = useState([]);
  const [myexample, setMyExample] = useState([]);
  const [myanswer, setMyAnswer] = useState([]);
  const [error, setError] = useState("");

  const processInputtask = (e) => setTask(e.target.value);

  let fetchData = async (e) => {
   
   
     try {
     
      const res = await fetch(e)
      const list = await res.json()
      setFQustion(list);
      const str1="success"
      setError(str1);
      console.log(error);
      console.log(list.err + " list data");
      const myObjStr = JSON.stringify(list);

      const abc = JSON.parse(myObjStr);

      setMyAnswer(arr => [...arr, abc]);
      setModuleid(abc[0].modules.moduleid);

      let sp = abc[0].example.split(/[#]/);

      setMyExample(sp);
    
     } catch (error) {
       console.log("error ocured");
       var err="error ocured";
       setError(err);
     }

   

  };

  //******************************** */
  const [inputItems, setInputItems] = useState([])
  const [users, setUsers] = useState([])
  const [userhistory, setUserHistory] = useState([]);
  const [singleUser, setSingleUser] = useState("")

  useEffect(() => {



  }, [])

  /*
    const processtask = (ap) => {
      var dd;
      fetch(`http://localhost:8080/sub/${ap}`)
      .then((response) => response.json())
     .then((data) => dd=setUsers(data))
     console.log(newtask +" api call");
     console.log(dd +" api call");
  
     
     };
  */
  //***************************** */
  const processtask = async (ap) => {



    const res = await fetch(`http://localhost:8080/sub/${ap}`);
    //console.log(e);
    const list = await res.json();
    setUserHistory(list)
    //  console.log(list);
    //setFQustion(list);
    console.log("list***************")
    console.log(list);
    


     // const abc = JSON.parse(myObjStr);
     
   


  };
  /**************************** */

  const {
    isOpen,
    getMenuProps,
    getInputProps,
    getComboboxProps,
    highlightedIndex,
    getItemProps,
  } = useCombobox({
    items: inputItems,
    onInputValueChange: ({ inputValue }) => {

      //
      // onkeyup(checkEnterKey);
      var d = inputValue;
      setTask(inputValue);
      setInputItems(
        users.filter((item) =>
          item.question.toLowerCase().startsWith(inputValue.toLowerCase())
        )
      )
    },
  })
  //******************************** */

  const checkEnterKey = (e) => {
   

    processtask(newtask);
    if (e.keyCode === 13) {
      console.log(".............................");
      console.log(newtask+" new task...");
      //addNewTask(newtask);
      dispp(newtask);
    }

  };

  const addNewTask = (e) => {
   
    dispp(newtask);

    setTask("");
  };


  const dispp = (e) => {
    
    setTask(e); 

   
    setSingleUser(e);
    console.log(e + " answer search......");
    const url = `http://localhost:8080/sub/${e}`;
    

    fetchData(url);


  };

  const postDatatoServer = async (data) => {
    const udata = localStorage.getItem('userData');
    const userdetails = JSON.parse(udata);

    //var localData = localStorage.getItem('udata.username');


    const userid = userdetails.id;

    var users = {
      "user_id": userid,
      "question": newtask,
      "modules_moduleid": moduleid,
    }



    //setUserHistory(user,userhistory);
    //console.log(userhistory+" value");
    //we have to pass data
    // console.log(newtask);

    await fetch(`http://localhost:8080/history/idata`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(users),
    });


  };

  const disp = (e) => {
    // console.log(e.keyword);
    setSingleUser(e); // auto sugestion data pass here.
    console.log(e + " value");
    setTask(e);

    const url = `http://localhost:8080/sub/${e}`;

    fetchData(url);


  };
  return (


    <div className="container-fluid" >
   
      <div class="card  mt-2" style={{ maxWidth:"1000px", maxHeight:"600px"}}>
        <div class="card-header text-light font-weight-bold " style={{ backgroundColor: "rgba(127, 83, 172, 0.8)" }}>
          <div className="row">
            <div className="col-9 mr p-12">
          <h3 >chat Bot</h3>
          </div>
          <div className="col-md-3 col-sm-12">
          <button class="btn" style={{backgroundColor:"#fefae0"}} onClick={postDatatoServer}
          >AddToWishList</button>
         </div>
          </div>
        </div>
        <div class="card-body " style={{ overflowY: "scroll", height: "500px",backgroundColor:"#rgba(126, 232, 250, 0.8)" }}>
              

        {myanswer.map((item, index) => (
           
           <div key={index}>




            
           <br/>
<div id="msg1" style={{padding:"0%",borderRadius:"30px",marginRight:"250px"}}>
 {item[0].question}
</div>

              <div id="msg2" style={{marginLeft:"50px",marginTop:"6px"}}>
              <div style={{padding:"0%",borderRadius:"30px"}}>
  {item[0].answer}
</div>
               
               </div>
             </div>

      
         ))}


           </div>
        
          
          <div class="card-footer bg-transparent p-0 pr-0">
            <div className="container-fluid">
              <div className="row">
              <div className="col-md-11  col-sm-12 pr-0">
              
          <div {...getComboboxProps()}>
        <input
          {...getInputProps()}
          placeholder="Search"
          enterButton="Search"
          class="form-control"
          size="large"
          onKeyUp={checkEnterKey}
          
       //   value={newtask} onChange={processInputtask} onKeyUp={checkEnterKey}
        />
      </div>
      <ul {...getMenuProps()}>
        {isOpen &&
          userhistory.map((item, index) => (
            <span
            //  key={item.id}
              {...getItemProps({ item, index })}
          // onClick={() => setSingleUser(item.keyword)}
         
          onClick={() => disp(item.question)} // set sugestion keyword
           
            >
              <h6
                style={{cursor: "pointer"}}
              >
                <h6>{item.question}</h6>
              </h6>
            </span>
          ))}
      </ul>
      </div>
      <div className="col-md-1 col-sm-12 ml-0">
          <button class="btn" style={{backgroundColor:"rgba(127, 83, 172, 0.8)"}} onClick={addNewTask}
          >Send</button>
         </div>
       
        </div>
      </div>
      </div>
      </div>



     

    </div>
  );
}

export default Chatbot;