import React, { useState, useEffect ,useLocation} from 'react'
import { Input } from "antd"
import { useCombobox } from "downshift"
import axios from 'axios';
import UserHistory from './UserHistory';
import './Tryc.css';

const Trydisplay = (props) => {
  const qArray = [];
console.log(props.uid+"user data..........");
 // const location = useLocation();
  const [fquestion, setFQustion] = useState([]);
  const [newtask, setTask] = useState("");
  const [questiond, setQustion] = useState([
  ]);
const [myquestion, setMyQuestion] = useState([]);
const [myanswer, setMyAnswer] = useState([]);

  const processInputtask = (e) => setTask(e.target.value);

  let fetchData = async (e) => {
    const res = await fetch(e);
    console.log(e);
    const list = await res.json();
    //  console.log(list);
    setFQustion(list);
    
    const myObjStr = JSON.stringify(list);

//console.log(myObjStr.question+"....."+myObjStr.answer);
// "{"name":"Sammy","age":6,"favoriteFood":"Tofu"}"
console.log("value...........");
const abc=JSON.parse(myObjStr);
//setMyQuestion( arr => [...arr, abc[0].question, abc[0].answer]);
setMyAnswer( arr => [...arr, abc]);
/*qArray.push({
  'question':abc[0].question,
  'answer':abc[0].answer
})*/
//var localData = localStorage.getItem('udata.username');

//const username = abc.question;
//const userid = abc.answer;
    console.log(abc[0].answer);
   // console.log(myArray);


    //
 // var xyz = JSON.stringify(qArray);
//console.log(xyz);   
//setMyAnswer( arr => [...arr, xyz]);
  };
  
  //******************************** */
  const [inputItems, setInputItems] = useState([])
  const [users, setUsers] = useState([])
  const [userhistory, setUserHistory] = useState([]);
  const [singleUser, setSingleUser] = useState("")

  useEffect(() => {
    

     
  }, [])


  const processtask = (ap) => {
    fetch(`http://localhost:8080/sub/${ap}`)
    .then((response) => response.json())
   .then((data) => setUsers(data))
   console.log(newtask +" api call");
   };

  const {
    isOpen,
    getMenuProps,
    getInputProps,
    getComboboxProps,
    highlightedIndex,
    getItemProps,
  } = useCombobox({
    items: inputItems,
    onInputValueChange: ({ inputValue }) => {
        
      //
      // onkeyup(checkEnterKey);
     var d=inputValue;
      setTask(inputValue);
      setInputItems(
        users.filter((item) =>
          item.question.toLowerCase().startsWith(inputValue.toLowerCase())
        )
      )
    },
  })
  //******************************** */

  const checkEnterKey = (e) => {
    console.log(e.keyCode);
   
    processtask(newtask);
    if (e.keyCode === 13) {
        console.log(newtask);
      //addNewTask(newtask);
      dispp(newtask);
    }

  };

  const addNewTask = (e) => {

   
   
        dispp(newtask);

    setTask("");
  };


  const dispp = (e) => {
    // console.log(e.keyword);
    setTask(e); // auto sugestion data pass here.
     
  

 
     setSingleUser(e);
     console.log(e+" key value");
    const url = `http://localhost:8080/sub/${e}`;
//console.log(e.answer);
   
    fetchData(url);

   
  };

  
 
  const postDatatoServer=(data)=>{
   

  var users = { 
    "user_id":props.uid,
    "question":newtask,
  }
  
 

 //setUserHistory(user,userhistory);
 //console.log(userhistory+" value");
    //we have to pass data
   // console.log(newtask);
     axios.post(`http://localhost:8080/history/idata`,users).then(
         (response)=>{
             console.log(response);
             console.log("success");
         },
         (error)=>{
          console.log(error);
          console.log("error");
         }

     )


     
};

  const disp = (e) => {
    // console.log(e.keyword);
    setSingleUser(e); // auto sugestion data pass here.
     console.log(e+" value");
     setTask(e);

    const url = `http://localhost:8080/sub/${e}`;

    fetchData(url);
  };


  return (


    <div className="container-fluid" >

      <div class="card  mt-5" style={{maxWidth:"700px"}}>
        <div class="card-header text-light font-weight-bold " style={{ backgroundColor: "blue" }}>
          <div className="row">
            <div className="col-9 mr p-12">
          <h3 >chat Bot</h3>
          </div>
          <div className="col-md-3 col-sm-12">
          <button class="btn btn-dark" onClick={postDatatoServer}
          >AddToWishList</button>
         </div>
          </div>
        </div>
        <div class="card-body" style={{ overflowY: "scroll", height: "400px" }}>
         
       
        <h6 >{singleUser} </h6>
        
        
          {fquestion.map((item, index) => (
           
            <div key={index}>




              <div class="card-body bg-info text-light" style={{marginLeft:"200px",border:"2px solid "}} >
            
                {item.answer}
                
              </div>

            </div>
            



          ))}
           </div>
        
          
          <div class="card-footer bg-transparent p-0 pr-0">
            <div className="container-fluid">
              <div className="row">
              <div className="col-md-11  col-sm-12 pr-0">
              
          <div {...getComboboxProps()}>
        <input
          {...getInputProps()}
          placeholder="Search"
          enterButton="Search"
          class="form-control"
          size="large"
          onKeyUp={checkEnterKey}
          
       //   value={newtask} onChange={processInputtask} onKeyUp={checkEnterKey}
        />
      </div>
      <ul {...getMenuProps()}>
        {isOpen &&
          inputItems.map((item, index) => (
            <span
              key={item.id}
              {...getItemProps({ item, index })}
          // onClick={() => setSingleUser(item.keyword)}
         
          onClick={() => disp(item.question)} // set sugestion keyword
           
            >
              <h6
                style={{cursor: "pointer"}}
              >
                <h6>{item.question}</h6>
              </h6>
            </span>
          ))}
      </ul>
      </div>
      <div className="col-md-1 col-sm-12 ml-0">
          <button class="btn btn-primary" onClick={addNewTask}
          >Send</button>
         </div>
        </div>
      </div>
      </div>
      </div>


     

{myanswer.map((item, index) => (
           
           <div key={index}>




             <div class="card-body bg-info text-light" style={{marginLeft:"200px",border:"2px solid "}} >
           
              <div> {item[0].question}

              </div>
              <div>
               {item[0].answer}
               </div>
             </div>

           </div>
           



         ))}
          
    </div>
  );
}


export default Trydisplay;