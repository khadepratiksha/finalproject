import React, { useEffect, useRef, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.css';



function FAQ() {
  
    
    useEffect(() => {
    
      fetchData();
     // console.log(value+".........");
         
    }, [])
    
    let fetchData = async () => {
      const res = await fetch(`http://localhost:8080/m/read`);
      console.log();
      const list = await res.json();
    
      setFQustion(list);
      
      const myObjStr = JSON.stringify(list);
    
      setMyAnswer(myObjStr);
    
    const abc=JSON.parse(myObjStr);
    
    };


    let ReadData = async (e) => {
      const res = await fetch(`http://localhost:8080/history/${e}`);
      console.log( res );
      const list = await res.json();
      //  console.log(list);
      setFQustion(list);
  
      console.log(list);
      updateMyArray( arr => [...arr, list]);
    };

    const [fquestion, setFQustion] = useState([ { question: "What is Java", action:<a href="#" className="btn btn-danger"><i className="fas fa-trash"></i></a>
  }]);
    const [value, setValue] = useState();
    const [myanswer, setMyAnswer] = useState([]);
    const [myArray, updateMyArray] = useState([]);

  

  var sub=(val)=>{
    setValue(val)
    const d=JSON.stringify(val);
    const abc = JSON.parse(d);
    console.log(abc.moduleid);
    ReadData(abc.moduleid);

  }

 

    return (
        
            
<div>


    

    <div className="container mt-5">
    
    
   
	    
      <div className="col-12">

<div style={{ width:200 }}  className="">
 <Dropdown 

 prompt="select modules..."
 options={fquestion} 
 id='id'
 label='modulename'
 value={value} 
 onChange={val=>{sub(val)}}

 />
</div>
<table className="table table-hover table-striped">
            <thead>
            <tr className="thead-dark">
                
                <th>Questions</th>
                
               
            </tr>
        </thead>
            <tbody>
            {myArray.map((item, index) => (
            <tr key={index}>
          <td >{item.question}</td>
          
          </tr>  ))}
                 </tbody>   
		            
		            </table>
           
                    </div>
                    </div>
                    </div>
    )
}


function  Dropdown({ 
  options ,
  id,
  label,
  prompt,
  value,
  onChange,
  })
  {
     
      const [open, setOpen] = useState(false);
       const ref = useRef(null);

       useEffect(() => {
         document.addEventListener("click",close);
         return()=>document.addEventListener("click",close);
         
       }, [])

     function close(e){
         // console.dir([e.target,ref.current])

          setOpen(e && e.target === ref.current )
     }



     return (
       <div className="dropdown">
         <div className="control"
         onClick={() => setOpen((prev)=>!prev)}>
             <div className="selected-value" ref={ref}>{value ? value.modulename: prompt}</div>
               <div className={` arrow ${open ? "open" : null} `} />
             </div> 
             <div className={` options ${open ? "open" : null} `}>
               {
                 options.map((option)=>(
                   <div 
                   key={option[id]}
                   className={` option ${value === option ? "selected" : null} `}
                  onClick={()=>{
                    onChange(option);
                    setOpen(false);
                   
                    
                  }} >
                     {option.modulename}</div>
                 ))
               } 
       </div>
       </div>
    
     );

}


export default FAQ;