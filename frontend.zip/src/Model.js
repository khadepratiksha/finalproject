import React from 'react';
import {Button, Modal} from 'react-bootstrap';
class Model extends React.Component{
  constructor()
  {
    super()
    this.state={
      show:false
    }
  }
  handleModal()
  {
    this.setState({show:!this.state.show})
  }
  render(){
    return (
      <div>
        
        <Button onClick={()=>{this.handleModal()}}>add module</Button>
        <Modal show={this.state.show} onHide={()=>this.handleModal()}>
        <Modal.Header closeButton></Modal.Header>
        <form>
        
                            <div className="form-group">
                              
                            <input Module Name className="form-control" type="text" name="Module Name" placeholder="Module Name" required="" autocomplete="off" aria-required="true" />
                            </div>
                            <div className="form-group">
                                <input type="text" name="pass" className="form-control" placeholder="Module Code" required="" autocomplete="off" aria-required="true" />
                            </div>
                            {/* <input className="btn btn-md btn-primary btn-center" id="login_btn" type="button" value="Login" /> */}
                       {/* <Button onClick={() => this.handleModal()} >Close</Button> */}
                       <Button onClick={() => this.handleModal()} >Save</Button>
                       </form>
          
        </Modal>
      </div>
      
    )
  }
}
export default Model;