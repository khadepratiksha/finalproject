import styled from '@emotion/styled';

export const App = styled.div`
  background: #ecf0f1;
  height: 100vh;
  display: flex
`

export const Header = styled.h1`
  color: pink
`