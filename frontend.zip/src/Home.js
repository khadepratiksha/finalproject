import React from 'react'
import { useState ,useEffect } from 'react';
import {  useLocation } from "react-router";
import 'bootstrap/dist/css/bootstrap.css'
import { Grid,Paper,Avatar} from '@material-ui/core'
import QuestionAnswerOutlinedIcon from '@material-ui/icons/QuestionAnswerOutlined';

import Default from './userlogin/Default';
import Chatbot from './Chatbot';



function Home(props) {
  const location = useLocation();

  
         const paperStyle={padding :20 , height:'70vh'}
          const avtarStyle={backgroundColor:"green"}


        const [que1, setQue] = useState({
            que:"",
            ans:"",
            submit:" "
           
        });

   const syncQue=(e)=>setQue({...que1,que:e.target.value});

   const syncAns=(e)=>setQue({...que1,ans:e.target.value});
    
   const submit = () =>{
    if (que1.que === "" || que1.ans === "") {
      return;
   }
   console.log("que1", que1);
   localStorage.setItem("app-que1", JSON.stringify(que1));

 };

 
    return (
        <div>
         
      <div className="row">
        <div className="col-3"></div>
        <div className="col-9 my-2">
        <div>
                Hello = {props.location.state}
                <Default user={props.location.state}/>
            </div>
           
        <Chatbot uid={props.location.uid}/>
        </div>
        </div>
        
       
         
</div>        
  
      
    )
}

export default Home;