import React, { useEffect, useState } from 'react'
import {  useLocation } from "react-router";
function UserHistory(props) {
    
    const location = useLocation();
    const [fquestion, setFQustion] = useState([]);
    const [myArray, updateMyArray] = useState([]);

    useEffect(() => {
    
        fetchData();
     
    }, [])

    
  let fetchData = async () => {

    const udata = localStorage.getItem('userData');
    const abc = JSON.parse(udata);

  
    const userid = abc.id;

    const res = await fetch(`http://localhost:8080/history/${userid}`);
    console.log( res );
    const list = await res.json();
    //  console.log(list);
    setFQustion(list);

    console.log(list);
    updateMyArray( arr => [...arr, list]);
  };

  let deleteData= async(e) =>{
console.log("id:"+e);
const url = `http://localhost:8080//history/${e}`;
//console.log(e.answer);
   
   await fetch(url,{method:"DELETE"});
fetchData();
  }
 
        console.log(location);
    return (
        <div>
         <div className="container mt-5">
    
    
   
    <div className="row">
       <div className=""></div>
        <table className="table table-hover table-striped">
            <thead>
            <tr className="thead-dark">
                
                <th>Questions</th>
                
                <th>Actions</th>
            </tr>
        </thead>
            <tbody>
            {fquestion.map((item, index) => (
            <tr key={index}>
          <td >{item.question}</td>
          <td> <button class="btn btn-danger" onClick={()=>deleteData(item.id)}
          ><i className="fas fa-trash" ></i></button></td>
          </tr>  ))}
                 </tbody>   
		            
		            </table>
           

</div>
        </div>


        
        </div>
    )
}

export default UserHistory
