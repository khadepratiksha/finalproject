import React from 'react'


   
function FormatText() {
    var foo = `
      (function(a, b) {
        var s = a.prop;
        // ...
      }(c, d));
    `
    return (
        <div>
             <pre>
        <code>{foo}</code>
      </pre>
        </div>
    )
}

export default FormatText;
