import React from 'react'
import { useState ,useRef,useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.css'
import { Grid,Paper,Avatar} from '@material-ui/core'
import QuestionAnswerOutlinedIcon from '@material-ui/icons/QuestionAnswerOutlined';
//import modules from './modules.json';
import './Style.css';


function AdminQuestion() {

         const paperStyle={padding :20 , height:'70vh'}
          const avtarStyle={backgroundColor:"green"}


        const [que1, setQue] = useState({
            question:"",
            answer:"",
            submit:" ",
            example:"",
            modules_moduleid:""
           
        });

       

        /************ */
          const [value, setValue] = useState();
          const [dopestion, setDOpstion] = useState();
         /*************/
   const syncQue=(e)=>setQue({...que1,question:e.target.value});

   const syncAns=(e)=>setQue({...que1,answer:e.target.value});

   const syncEx=(e)=>setQue({...que1,example:e.target.value});
   
   
   //const d=JSON.stringify(value);
        //  console.log(d );
    
   const submit = async() =>{
    const d=JSON.stringify(value);
    const abc = JSON.parse(d);
    setQue({...que1,modules_moduleid:abc.moduleid});
    // console.log("value..........."+abc.moduleid);
    // console.log("value..........."+que1.question);
     //console.log("value..........."+que1.answer);
    // que1.example= que1.example.replaceAll("{", "{#");
    // que1.example= que1.example.replaceAll(";", ";#");
     var subject = { 
      "question":que1.question,
      "answer":que1.answer,
      "example":que1.example,
      "modules_moduleid":abc.moduleid,
    }
    
     
    
    
    if (que1.que === "" || que1.ans === "") {
      return;
   }
  
  

   try {
    await fetch(`http://localhost:8080/sub/corejava`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(subject),
    });
  
   } catch (error) {
     
   }
  
 };

 const [myanswer, setMyAnswer] = useState([]);
 const [fquestion, setFQustion] = useState([]);
 

 useEffect(() => {
    
  fetchData();
 // console.log(value+".........");
     
}, [])

let fetchData = async () => {
  const res = await fetch(`http://localhost:8080/m/read`);
  console.log();
  const list = await res.json();

  setFQustion(list);
  
  const myObjStr = JSON.stringify(list);

  setMyAnswer(myObjStr);

const abc=JSON.parse(myObjStr);

};


    return (
        <div>
        
        
        <div className="row">
       
        <div className="col-12 my-2">
          <Grid style={{height:"600px"}}> 
              <div className="col-12">
               <Paper evalution={10} style={paperStyle}>
              <Grid align="center">    
               <Avatar style={avtarStyle}> <QuestionAnswerOutlinedIcon /></Avatar>
               <h3>Questions & Answers</h3>

      <form>
                <div className="row">
                  <div className="col-12">

                 <div style={{ width:200 }}  className="">
                  <Dropdown 
                 
                  prompt="select modules..."
                  options={fquestion} 
                  id='id'
                  label='modulename'
                  value={value} 
                  onChange={val => setValue(val)}
                
                  />
                 </div>
               <div className="form-group mt-2 ">
                   
               <label for="que">Add Question</label>
               
               <input type="text" 
               className="form-control mb-1" 
               id="que"
               value={que1.question} 
               onChange={syncQue}
               placeholder="add your questions...." />
               </div>

               <div class="form-group mb-2">
               <label for="ans" className="mb-2">Add Answer</label>
               <textarea className="form-control mb-1" 
               id="ans"   rows="3" 
               value={que1.answer}
               onChange={syncAns}
               placeholder="write your answer...."></textarea>
              </div>

              <div class="form-group mb-2">
               <label for="ans" className="mb-2">Add Answer</label>
               <textarea className="form-control mb-1" 
               id="ans" rows="3" 
               value={que1.example}
               onChange={syncEx}
               placeholder="write your answer...."></textarea>
              </div>

              

              <button onClick={submit} type="button" id="submit" className="btn btn-success btn-block mb-2" >Submit</button>
              <button type="button" id="clear" className="btn btn-danger btn-block ">Clear</button>
    </div>
    </div>
      </form>  
                     
            </Grid>
              
                   </Paper>
                   </div>
                   </Grid>    
              
                 
                     </div>

                     </div>
      
         
</div>        
  
      
    )
}

 function  Dropdown({ 
   options ,
   id,
   label,
   prompt,
   value,
   onChange,
   })
   {
      
       const [open, setOpen] = useState(false);
        const ref = useRef(null);

        useEffect(() => {
          document.addEventListener("click",close);
          return()=>document.addEventListener("click",close);
          
        }, [])

      function close(e){
          // console.dir([e.target,ref.current])

           setOpen(e && e.target === ref.current )
      }



      return (
        <div className="dropdown">
          <div className="control"
          onClick={() => setOpen((prev)=>!prev)}>
              <div className="selected-value" ref={ref}>{value ? value.modulename: prompt}</div>
                <div className={` arrow ${open ? "open" : null} `} />
              </div> 
              <div className={` options ${open ? "open" : null} `}>
                {
                  options.map((option)=>(
                    <div 
                    key={option[id]}
                    className={` option ${value === option ? "selected" : null} `}
                   onClick={()=>{
                     onChange(option);
                     setOpen(false);
                    
                     
                   }} >
                      {option.modulename}</div>
                  ))
                } 
        </div>
        </div>
     
      );

 }

export default AdminQuestion;