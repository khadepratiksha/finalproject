import React from "react";
import {  useHistory, useLocation } from "react-router";
import { Navbar } from "reactstrap";

function Default (props) {

    const location = useLocation();
    let history = useHistory();

    console.log(location+" logout");
   
   const logout = () => {
       localStorage.clear(props.location.state);
       // localStorage.clear(props.location.state);

        history.push(
            {
            pathname : "/"
         }
         );
    }

   

// in retrurn
    return(
        <div>
          
          <div>
                <button type="submit" onClick={logout}>Logout</button>
            </div>


        </div>
    )
}

export default Default;