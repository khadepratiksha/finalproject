import React, { Fragment, useEffect, useState } from 'react';
import { useHistory } from 'react-router';
import { Button, Container, Form, FormGroup, Input, Label } from 'reactstrap';
//import "./login.css";



const Login = () => {
  useEffect(() => {
    document.title = "add user";
  }, []);

  let history = useHistory();
  // usesate it create state
  const [User, setUser] = useState({});
  // form handler function

  const handleForm = (e) => {
    console.log(User);
    postDatatoServer(User);
    e.preventDefault();
  };

  const fetchdata = async (ur, User) => {
    const res = await fetch(ur);
    console.log(ur);
    const list = await res.json();
    console.log(list.id + "  user id");
    var userData = {
      "username": list.username,
      "id": list.id
    }
    //  localStorage.setItem("id" , list.id );
    localStorage.setItem('userData', JSON.stringify(userData));
    // localStorage.setItem( "username" , list.username  )

    const udata = localStorage.getItem('userData');
    const abc = JSON.parse(udata);

    //var localData = localStorage.getItem('udata.username');

    const username = abc.username;
    const userid = abc.id;






try {
  if (username == User.username) {
    // console.log(localData + " value of localdata");

    history.push(
      {
        pathname: "/h",
        state: username,
        uid: userid,

      }

    );

  } 
} catch (error) {
  console.log(error)
}

    
  }


  // create function to post data on server
  const postDatatoServer = (e) => {
    //we have to pass data

    const url = `http://localhost:8080/p1/a${e.username}`;
    console.log(e.username)
    fetchdata(url, e);
  };
  return (
    <Fragment className="bd-dark">

      <div className="card text-center mt-5" style={{ width: "600px", marginLeft: "230px" }}>
        <div className="card-header">
          <h3 style={{ fontFamily: "cursive", color: "burlywood" }}>Login from</h3>
        </div>
        <div className="card-body">
          <Form onSubmit={handleForm}>
            <FormGroup>
              <Label for="username1"><h6>Name</h6></Label>
              <Input type="text" placeholder="enter name" name="username" id="username1" required
                onChange={(e) => {
                  setUser({ ...User, username: e.target.value });
                }}
              />
            </FormGroup>
            <FormGroup>
              <Label for="userpassword"><h6>Password</h6></Label>
              <Input type="password" placeholder="enter password" name="password" id="userpassword" required
                onChange={(e) => {
                  setUser({ ...User, password: e.target.value });
                }}
              />
            </FormGroup>

            <Container className="text-center">
              <Button type="submit" color="success">Login</Button>
              <Button color="warning ml-2" href="/register">Register</Button>
            </Container>
          </Form>


        </div>
        <div className="card-footer text-muted">

        </div>
      </div>
    </Fragment>



  )
}

export default Login;