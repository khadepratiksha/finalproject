import axios from 'axios';
import React,{Fragment, useEffect, useState} from 'react';
import { Button, Container, Form, FormGroup, Input, Label } from 'reactstrap';
//import "./login.css";



const Register=()=>{
  useEffect(()=>{
      document.title="register user";
   },[]);
// usesate it create state
   const [User,setUser]=useState({});
// form handler function

   const handleForm=(User)=>{
       console.log(User);
       postDatatoServer(User);
       User.preventDefault();
   };

   const fetchdata = async (ur) =>{
    const res = await fetch(ur);
    console.log(ur);
    const list = await res.json();
     console.log(list);

   }
  

// create function to post data on server
const postDatatoServer=(e)=>{
  //we have to pass data
   
  // const url = `http://localhost:8080/p1/register`,e;
   // api for registrastion
  // fetchdata(url);
/*
  useEffect(() => {
    // POST request using fetch inside useEffect React hook
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: 'React Hooks POST Request Example' })
    };
    fetch('https://jsonplaceholder.typicode.com/posts', requestOptions)
        .then(response => response.json())
        .then(data => setPostId(data.id));

// empty dependency array means this effect will only run once (like componentDidMount in classes)
}, []);
*/


  axios.post(`http://localhost:8080/p1/register`,e.username).then(
    (response)=>{
        console.log(response);
        console.log("success");
    },
    (error)=>{
     console.log(error);
     console.log("error");
    }

)


   
};
  return(
  <Fragment  className="bd-dark">
 
  <div className="card text-center mt-5" style={{width: "600px",marginLeft:"230px"}}>
  <div className="card-header">
    <h3 style={{fontFamily:"cursive",color:"burlywood"}}>Registration</h3>
  </div>
  <div className="card-body">
  <Form onSubmit={handleForm}>
      <FormGroup>
          <Label for="username1"><h6>Name</h6></Label>
          <Input type="text" placeholder="enter name" name="username" id="username1"
          onChange={(e)=>{
              setUser({...User,username: e.target.value});
          }}
          />
      </FormGroup>
      <FormGroup>
          <Label for="userpassword"><h6>Password</h6></Label>
          <Input type="password" placeholder="enter password" name="password" id="userpassword"
           onChange={(e)=>{
              setUser({...User,password: e.target.value});
          }}
          />
      </FormGroup>
      
      <Container className="text-center">
          <Button color="warning ">Register</Button>
          <Button type="submit" color="success ml-2" href="/login">Login</Button>
      </Container>
  </Form>


  </div>
  <div className="card-footer text-muted">
  
  </div>
</div>
  </Fragment>



  )
}

export default Register;