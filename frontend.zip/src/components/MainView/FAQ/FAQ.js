import React from 'react';

const FAQ = () => {
  return <h1>Frequently Asked Questions</h1>
}

export default FAQ