import React from 'react';

const Module = () => {
  return <h1>Module Page</h1>
}

export default Module