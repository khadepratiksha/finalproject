import React from 'react';
import * as s from "./Country.styles";

const Country = props => {
  const country = props.match.params.country;
  const countries = {
    canada: {
      img: '/images/countries/canada.png',
      description: 'JAVA'
    },
    brazil: {
      img: '/images/countries/brazil.jpg',
      description: 'DAATABASE'
    },
    australia: {
      img: '/images/countries/australia.jpg',
      description: 'OPERATING SYSTEM'
    },
    india: {
      img: '/images/countries/india.jpg',
      description: 'DATA STRUCTURE'
    },
    moldova: {
      img: '/images/countries/moldova.jpeg',
      description: 'WEB PROGRAMMING'
    },
    kenya: {
      img: '/images/countries/kenya.jpg',
      description: 'WEB JAVA'
    }
  }

  return (
    <s.CountryContainer>
      <s.CountryImage img={countries[country]['img']} />
      <s.CountryDescription>{countries[country]['description']}</s.CountryDescription>
    </s.CountryContainer>
  )
}

export default Country