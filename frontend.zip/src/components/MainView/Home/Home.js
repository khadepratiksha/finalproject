import React from 'react';

const Home = () => {
  return <h1>Welcome To Chat Bot</h1>
}

export default Home