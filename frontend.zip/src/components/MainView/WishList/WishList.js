import React from 'react';

const WishList = () => {
  return <h1>Wishlist</h1>
}

export default WishList