import React from 'react';

const History = () => {
  return <h1>History Page</h1>
}

export default History