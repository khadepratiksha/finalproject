<p align="center">
  <img width="150" src="https://eugeville.files.wordpress.com/2015/03/logo.png" alt="Stylish Sidebar logo">
</p>

<h1 align="center">Stylish React Sidebar</h1>

A reusable stylish sidebar that can be imported into an application.

Sample written for a [Youtube code walkthrough](https://www.youtube.com/watch?v=NsYnjubWu2c).
