package chat.bot;
public class T{

    public static void main(String[] args)
{ MyThread t=new MyThread();
t.start();
for (int i=0;i<5 ;i++ )
{ System.out.println("main thread");
}
}

}

class MyThread extends Thread
{
	// @Override
	
  public void start() { // overriding the start() method
     System.out.println("Overriding a start() method");
   //  super.start();
     run();// we can also call run method within a start method
  }
  
  @Override
  public void run() {
     System.out.println("run() method ");
  }
}

