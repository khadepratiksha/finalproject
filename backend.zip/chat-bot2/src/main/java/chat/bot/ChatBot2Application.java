package chat.bot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatBot2Application {

	public static void main(String[] args) {
		SpringApplication.run(ChatBot2Application.class, args);
		System.out.println("Hello");
	}

}
