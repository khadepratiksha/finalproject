package chat.bot.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import chat.bot.dao.Modules;
import chat.bot.dao.Subject;





public interface ModuleRepository extends JpaRepository<Modules, Integer>{

	@Query(nativeQuery=true, value="select moduleid,modulename from modules;")
	List<Modules> findAllData();

}
