package chat.bot.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import chat.bot.dao.User;

public interface UserRepository extends JpaRepository<User, Integer> {
	@Query(nativeQuery=true, value="SELECT * from User where username =:username")
	  User findByUsername(String username); 
	
	@Query(nativeQuery=true, value="SELECT * from User where emailid =:emailid")
  User findByEmail(String emailid); 

	
}
