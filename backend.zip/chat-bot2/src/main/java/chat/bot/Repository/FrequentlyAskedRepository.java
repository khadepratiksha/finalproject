package chat.bot.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import chat.bot.dao.FrequentlyAsked;

public interface FrequentlyAskedRepository extends  JpaRepository<FrequentlyAsked, Integer>{

}
