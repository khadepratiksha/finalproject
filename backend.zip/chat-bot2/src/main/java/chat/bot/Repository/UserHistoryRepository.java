package chat.bot.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import chat.bot.dao.Subject;
import chat.bot.dao.User;
import chat.bot.dao.UserHistory;

public interface UserHistoryRepository extends JpaRepository<UserHistory, Integer> {
	@Query(nativeQuery=true, value="SELECT * from user_history where user_history.user_id =?")
	List<UserHistory> findByHistory(int user_id); 
	
	
	
}
