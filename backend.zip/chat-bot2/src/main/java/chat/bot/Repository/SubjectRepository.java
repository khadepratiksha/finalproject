package chat.bot.Repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import chat.bot.dao.Subject;





public interface SubjectRepository extends JpaRepository<Subject,Integer> {

	//@Query(value = "SELECT sub FROM Subject sub where keyword=:keywd")
	//List<Subject> readkeyword(String keywd);
	
	

	//@Query(nativeQuery=true, value="SELECT * FROM Subject WHERE question like ?1")
	//List<Subject> findByKeyword(String regex);
	
	@Query(nativeQuery=true, value="SELECT * FROM Subject WHERE keyword LIKE %?1%")
	List<Subject> findByKeyword(String keyword);
	
	@Query(nativeQuery=true, value="SELECT * FROM Subject WHERE question LIKE %?1%")
	Subject findByquestion(String question);
	
	
/*	@Query(nativeQuery=true, value="SELECT * FROM Subject WHERE question regexp ?1")
	List<Subject> findByQuestion(String regex);
*/
}
