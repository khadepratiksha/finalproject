package chat.bot.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import chat.bot.Repository.ModuleRepository;
import chat.bot.Repository.SubjectRepository;
import chat.bot.dao.Modules;
import chat.bot.dao.Subject;
import chat.bot.dao.User;
import chat.bot.dao.UserH;
import chat.bot.dao.UserHistory;

@RestController
@RequestMapping("/sub")
public class SubjectController {

	@Autowired
	SubjectRepository core;

	@Autowired
	ModuleRepository moduler;

     @CrossOrigin
	@PostMapping("/corejava")
	public Subject insert(@RequestBody UserH h) {
		
         
         Subject sub=new Subject();
        sub.setCount(0);
         sub.setModules(new Modules(h.modules_moduleid));
         sub.setQuestion(h.question);
         sub.setAnswer(h.answer);
         sub.setExample(h.example);
         String que=create1(h.question);
         sub.setKeyword(que);
       
		return core.save(sub);

	}

	
	@CrossOrigin
	@GetMapping("/data")
	public List<Subject> readAll() {
		
		return  core.findAll();

	}

	

	//@CrossOrigin
	//@PostMapping("/insertdata")
	public String create1(String question) {

		String sentence = question;
		String stopWords[] = { "what", "is", "and", "or", "a", "with", "are", "the", "that", "to","can","in","how","why","we","output","answer" ,"do","does"};
		String listString = "";

		System.out.println("Core Java Example");

		String text = question.toLowerCase().trim();

		ArrayList<String> wordList = new ArrayList();
		wordList.addAll(Arrays.asList(text.split(" ")));

		List<String> stopWordList = new ArrayList<>();
		stopWordList.addAll(Arrays.asList(stopWords));

		wordList.removeAll(stopWordList);
		System.out.println("Text without stop words:" + wordList.toString());

		for (String string : wordList) {
			listString += string + " ";
		}

	

		//user.setKeyword(listString);

	//	System.out.println(user.getKeyword());
		return listString;
	}

	@CrossOrigin
	@PostMapping("/idata")
	public void createm(@RequestBody Modules m) {
		// System.out.println(m.getModulename());
		//System.out.println("hello..........");
		moduler.save(m);

	}
	
	// mapping particular data
/*
	@GetMapping("/{keyword}")
	public List<Subject> read111(@PathVariable String keyword) {
		
		return  core.readkeyword(keyword);

	}
	*/
	
	
	
	
	
	
	@CrossOrigin
	@GetMapping("/{keyword}")
	public List<Subject> read111(@PathVariable String keyword) {
		System.out.println("....................");
		List<Subject> sub=null;
		String que=create1(keyword);
		
		System.out.println(keyword+".................value");
		String str;
		//boolean flag=false;
	
		try {
			System.out.println("hello...");
			if((que!=""))
			{
			 sub=core.findByKeyword(que);
			}else {
				sub=null;
			}
			
			
				/*for (Subject subject : sub) {
					//str=subject.getQuestion();
					if(keyword==subject.getQuestion())
					{
						flag=true;
						break;
					}
					else {
						flag=false;
						System.out.println(".......");
					}
					//System.out.println(subject.getQuestion());
				}
				
				
				*/
			
			if(sub.size()==0)
			{
				sub=null;
			}
		} 
		catch (Exception e) {
			System.out.println("error occured");
			return sub;
			
		}
		
	
		return  sub;

	}
	
	
	
	
	
	
	
	
	@CrossOrigin
	@GetMapping("/que{question}")
	public Subject fetchquestion(@PathVariable String question) {
		Subject sub=core.findByquestion(question);
		System.out.println("shbagDGJWJASH");
	/*	try {
			
			
			int c=	sub.getCount();
			System.out.println(c+" count");
			System.out.println("......................"+question!=sub.getQuestion()||sub.getQuestion()==null);
			if(question!=sub.getQuestion()||sub.getQuestion()==null)
			{
				return sub=null;
			}else
			{
				return sub;
			}
		
		} catch (Exception e) {
			
			System.out.println("error ocurred");
		}
	*/
	return  sub;

	}
	

	/*@CrossOrigin
	@GetMapping("/{que}")
	public List<Subject> readPerticularData(@PathVariable String question) {
		
		return  core.findByQuestion(question);

	}
*/

	
}
