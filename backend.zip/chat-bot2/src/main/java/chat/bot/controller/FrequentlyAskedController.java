package chat.bot.controller;

import org.springframework.beans.factory.annotation.Autowired;

import chat.bot.Repository.FrequentlyAskedRepository;

public class FrequentlyAskedController {
	@Autowired
	FrequentlyAskedRepository asked;

}
