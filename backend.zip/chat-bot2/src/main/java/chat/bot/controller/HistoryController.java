package chat.bot.controller;

import java.util.ArrayList;
import java.util.List;
import java.io.*; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import chat.bot.Repository.UserHistoryRepository;
import chat.bot.dao.Modules;
import chat.bot.dao.User;
import chat.bot.dao.UserH;
import chat.bot.dao.UserHistory;

@RestController
@RequestMapping("/history")
public class HistoryController {
	@Autowired
	private UserHistoryRepository userhistory;
	
	@Override
	 public String toString(){//overriding the toString() method  
		 UserHistory h=new UserHistory();
		  return h.getQuestion();  
		 }  

	@CrossOrigin
	@PostMapping("/idata")
	public void addQustion(@RequestBody UserH UserH) {
		
//User u=new User();

UserHistory userHistory=new UserHistory();
          userHistory.setUser(new User(UserH.user_id));
			System.out.println(UserH.user_id);
			
			
			 userHistory.setModules(new Modules(UserH.modules_moduleid));
				System.out.println(UserH.modules_moduleid);
			userHistory.setQuestion(UserH.question);		
			userhistory.save(userHistory);

	}
	
	

	@CrossOrigin
	@GetMapping("/data")
	public List<Object> readAll() {
		List<UserHistory> h=userhistory.findAll();
		List<Object> h1=new ArrayList<>(h);
        return h1;
	}
	

	@CrossOrigin
	@DeleteMapping("/{id}")
	public boolean deleteUser(@PathVariable int id) {
		userhistory.deleteById(id);
		return true;
	}
	
	@CrossOrigin
	@GetMapping("/{id}")
	public List<UserHistory> login(@PathVariable int id) {
		List<UserHistory>  userdetails=userhistory.findByHistory(id);
		return userdetails;
		
	}
}
