package chat.bot.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import chat.bot.Repository.ModuleRepository;
import chat.bot.Repository.UserRepository;
import chat.bot.dao.Subject;
import chat.bot.dao.User;


@RestController
@RequestMapping("/p1")
public class UserController {

	@Autowired
	UserRepository userrepository;
	
	@Autowired
	ModuleRepository module;
	
	
	
	@CrossOrigin
	@PostMapping("/in")
	public User insert(@RequestBody User u) {
		// TODO Auto-generated method stub
		
		
			return userrepository.save(u);
			
		
	}
	
	@CrossOrigin
	 @PostMapping("/register")
	 	public User create1(@RequestBody User user)
	 	{
		
		System.out.print(user);
	 	return userrepository.save(user);
	 	}

	
	@DeleteMapping("/{id}")
	public boolean deleteUser(@PathVariable int id) {
		userrepository.deleteById(id);
		return true;
	}

	/*
	@GetMapping("/{id}")
	public User readAll(@PathVariable int id) {

		
	return	userrepository.findById(id).get();
			
	}
	*/
	@CrossOrigin
	@GetMapping("/a{username}")
	public User login(@PathVariable String username) {
		 User use = userrepository.findByUsername(username);
		System.out.print(use);
		
		if(use.getUsername() == null) {
            throw new RuntimeException("User does not exist.");
        }
        if(!use.getUsername().equals(username)){
            throw new RuntimeException("Username mismatch.");
        }
        return use;
        
		
		//return userRepository.findByUsername(username);
	}
	
	
	@CrossOrigin
	@GetMapping("/{emailid}")
	public User read(@PathVariable String emailid) {
		User user=userrepository.findByEmail(emailid);
		return  user;

	}


}
