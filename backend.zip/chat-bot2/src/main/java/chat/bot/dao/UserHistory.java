package chat.bot.dao;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class UserHistory {
	@Id
	@GeneratedValue
	private int id;
	private int marks;
	//private int user_id;
	private String question;

	@ManyToOne
	private Modules mod;

	@ManyToOne
	//@Column(columnDefinition = "int")
	@JoinColumn(name="user_id")
	private User user;

	public UserHistory() {
		super();
	}

	public UserHistory(int marks, String question, Modules modules, User user) {
		super();
		this.marks = marks;
		this.question = question;
		this.mod = modules;
		this.user = user;
		//this.user_id = uid;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public Modules getModules() {
		return mod;
	}

	public void setModules(Modules modules) {
		this.mod = modules;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	

	/*public int getUid() {
		return user_id;
	}

	public void setUid(int uid) {
		this.user_id = uid;
	}
*/
}
