package chat.bot.dao;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class FrequentlyAsked {
	@Id
	@GeneratedValue
	private int id;
	
	//private int user_id;
	private String question;

	@ManyToOne
	private Modules modulefrequently;

	
	public FrequentlyAsked() {
		super();
		// TODO Auto-generated constructor stub
	}


	public FrequentlyAsked(int marks, String question, Modules modulefrequently) {
		super();
		
		this.question = question;
		this.modulefrequently = modulefrequently;
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	
	
	
}
