package chat.bot.dao;

public class UserH {
	
	public  int user_id = 0;
	public String question = null ;
	
	public String answer=null;
	public String example=null;
	
	public int modules_moduleid=0;
	
	public boolean submitedata;
	
	

}
