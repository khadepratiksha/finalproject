package chat.bot.dao;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Subject")
public class Subject {
 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int keyid;
	
	private int count;
	@Column(columnDefinition="TEXT",nullable = true)
	private String question;
	@Column(columnDefinition="TEXT")
	private String answer;
	
	@Column(columnDefinition="TEXT")
	private String keyword;
	
	public String getKeyword() {
		return keyword;
	}


	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}


	@Column(columnDefinition="TEXT")
	private String example;

	@ManyToOne
	private Modules modules;
	
	
	public Subject() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	


	public Subject(int count, String question, String answer, String keyword, String example, Modules modules) {
		super();
		this.count = count;
		this.question = question;
		this.answer = answer;
		this.keyword = keyword;
		this.example = example;
		this.modules = modules;
	}


	public int getKeyid() {
		return keyid;
	}
	public void setKeyid(int keyid) {
		this.keyid = keyid;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public int getCount() {
		return count;
	}


	public void setCount(int count) {
		this.count = count;
	}

	public Modules getModules() {
		return modules;
	}

	public void setModules(Modules modules) {
		this.modules = modules;
	}


	public String getExample() {
		return example;
	}


	public void setExample(String example) {
		this.example = example;
	}
	
	
}
