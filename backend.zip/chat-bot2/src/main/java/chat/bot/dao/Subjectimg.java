package chat.bot.dao;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the subjectimg database table.
 * 
 */
//@Entity
//@NamedQuery(name="Subjectimg.findAll", query="SELECT s FROM Subjectimg s")
public class Subjectimg implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int imgId;

	@Lob
	private byte[] image;

	//bi-directional many-to-one association to Subject
	@ManyToOne
	@JoinColumn(name="sid")
	private Subject subject;

	public Subjectimg() {
	}

	public int getImgId() {
		return this.imgId;
	}

	public void setImgId(int imgId) {
		this.imgId = imgId;
	}

	public byte[] getImage() {
		return this.image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	public Subject getSubject() {
		return this.subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

}